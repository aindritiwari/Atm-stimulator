-- SQL schema for ATM Simulator
CREATE TABLE UserAccount (
    accountNumber INT PRIMARY KEY,
    pin INT NOT NULL,
    balance DECIMAL(10, 2) NOT NULL
);