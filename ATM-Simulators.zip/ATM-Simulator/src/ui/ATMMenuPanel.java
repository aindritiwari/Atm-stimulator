package ui;
import dao.UserAccountDAO;
import model.UserAccount;
import javax.swing.*;                           
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
public class ATMMenuPanel extends JPanel {
    private UserAccount userAccount;
    private UserAccountDAO userAccountDAO;
    public ATMMenuPanel(UserAccount userAccount) {
        this.userAccount = userAccount;
        this.userAccountDAO = new UserAccountDAO();
        setLayout(new GridLayout(3, 1));
        JButton checkBalanceButton = new JButton("Check Balance");
        checkBalanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(ATMMenuPanel.this, "Balance: " + userAccount.getBalance());
            }
        });
        add(checkBalanceButton);
        JButton withdrawButton = new JButton("Withdraw");
        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleWithdraw();
            }
        });
        add(withdrawButton);
        JButton depositButton = new JButton("Deposit");
        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleDeposit();
            }
        });
        add(depositButton);
    }
    private void handleWithdraw() {
        String amountStr = JOptionPane.showInputDialog(this, "Enter amount to withdraw:");
        try {
            double amount = Double.parseDouble(amountStr);
            if (amount > 0 && userAccount.getBalance().doubleValue() >= amount) {
                userAccount.setBalance(userAccount.getBalance().subtract(BigDecimal.valueOf(amount)));
                userAccountDAO.updateBalance(userAccount.getAccountNumber(), userAccount.getBalance().doubleValue());
                JOptionPane.showMessageDialog(this, "Withdrawal successful. New balance: " + userAccount.getBalance());
            } else {
                JOptionPane.showMessageDialog(this, "Insufficient balance or invalid amount.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
    private void handleDeposit() {
        String amountStr = JOptionPane.showInputDialog(this, "Enter amount to deposit:");
        try {
            double amount = Double.parseDouble(amountStr);
            if (amount > 0) {
                userAccount.setBalance(userAccount.getBalance().add(BigDecimal.valueOf(amount)));
                userAccountDAO.updateBalance(userAccount.getAccountNumber(), userAccount.getBalance().doubleValue());
                JOptionPane.showMessageDialog(this, "Deposit successful. New balance: " + userAccount.getBalance());
            } else {
                JOptionPane.showMessageDialog(this, "Invalid amount.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}