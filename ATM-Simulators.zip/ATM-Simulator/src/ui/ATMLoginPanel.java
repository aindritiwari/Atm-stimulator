package ui;
import dao.UserAccountDAO;
import model.UserAccount;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class ATMLoginPanel extends JPanel {
    private JTextField accountNumberField;
    private JPasswordField pinField;
    private UserAccountDAO userAccountDAO;
    public ATMLoginPanel() {
        userAccountDAO = new UserAccountDAO();
        setLayout(new GridLayout(3, 2));
        add(new JLabel("Account Number:"));
        accountNumberField = new JTextField();
        add(accountNumberField);
        add(new JLabel("PIN:"));
        pinField = new JPasswordField();
        add(pinField);
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });
        add(loginButton);
    }
    private void handleLogin() {
        try {
            int accountNumber = Integer.parseInt(accountNumberField.getText());
            int pin = Integer.parseInt(new String(pinField.getPassword()));
            UserAccount userAccount = userAccountDAO.getUserAccount(accountNumber);
            if (userAccount != null && userAccount.getPin() == pin) {
                JOptionPane.showMessageDialog(this, "Login successful!");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid account number or PIN.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}