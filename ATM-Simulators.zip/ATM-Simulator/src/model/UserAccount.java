package model;
import java.math.BigDecimal;
public class UserAccount {
    private int accountNumber;
    private int pin;
    private BigDecimal balance;
    public UserAccount(int accountNumber, int pin, BigDecimal balance) {
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.balance = balance;
    }
    public int getAccountNumber() {
        return accountNumber;
    }
    public int getPin() {
        return pin;
    }
    public BigDecimal getBalance() {
        return balance;
    }
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
}