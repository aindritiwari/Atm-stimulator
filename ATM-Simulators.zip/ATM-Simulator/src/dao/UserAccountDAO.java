package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.UserAccount;
public class UserAccountDAO {
    public UserAccount getUserAccount(int accountNumber) throws SQLException {
        String query = "SELECT * FROM UserAccount WHERE accountNumber = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, accountNumber);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new UserAccount(
                    resultSet.getInt("accountNumber"),
                    resultSet.getInt("pin"),
                    resultSet.getBigDecimal("balance")
                );
            }
        }
        return null;
    }
    public void updateBalance(int accountNumber, double newBalance) throws SQLException {
        String query = "UPDATE UserAccount SET balance = ? WHERE accountNumber = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDouble(1, newBalance);
            statement.setInt(2, accountNumber);
            statement.executeUpdate();
        }
    }
}